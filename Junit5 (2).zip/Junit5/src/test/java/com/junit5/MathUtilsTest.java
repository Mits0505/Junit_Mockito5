package com.junit5;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.OS;

@TestInstance(TestInstance.Lifecycle.PER_METHOD)
@DisplayName("When running MathUtils")
class MathUtilsTest {

	MathUtils mathUtils;
	
	@BeforeAll
	static void beforeAllInit() {
		System.out.println("Initializations.");
	}
	@BeforeEach
	void init() {
		mathUtils = new MathUtils();
	}
	
	@Nested
	@DisplayName("add method")
	class AddTest{
		
	@Test
	@DisplayName("when adding two positive numbers.")
	void testAddPositive() {
		int expected = 5;
		int actual = mathUtils.sum(3,2);
		assertEquals(expected, actual, "should return the right sum.");
	}
	
	@Test
	@DisplayName("when adding two positive numbers.")
	void testAddNegative() {
		int expected = -5;
		int actual = mathUtils.sum(-3,-2);
		assertEquals(expected, actual, ()->"should return sum "+expected+" but returned "+actual); //Lazy loading of message, so that it won't be calculated in case of test pass.
	 }
	}
	
	@Test
	void testMultiply() {
		
		assertAll(()->assertEquals(4, mathUtils.multiply(2, 2)),
				()->assertEquals(2, mathUtils.multiply(2, 1)),
				()->assertEquals(-2, mathUtils.multiply(-2, 1))
				 );
		
	}
	
	@Test
	@EnabledOnOs(OS.WINDOWS)
	void testDivide() {
		boolean isServerUp = false; // From certain conditions, I got this value as false.
		assumeTrue(isServerUp);
		assertThrows(ArithmeticException.class, ()->mathUtils.divide(1, 0),"Divide by 0 should throw an exception.");
	}
	
	@Test
	@Disabled
	void testComputeCircleArea() {

		assertEquals(314.1592653589793, mathUtils.computeCircleArea(10),"Should return right circle area");
	}
	
	@AfterEach
	void cleanup() {
		System.out.println("Clening up.");
	}
}
